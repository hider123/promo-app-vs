import React, { useState } from 'react';
import { 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword,
    GoogleAuthProvider,
    signInWithPopup
} from 'firebase/auth';

// 應用程式 Logo SVG 元件
const AppLogo = () => (
    <svg className="w-12 h-12 mx-auto text-indigo-600" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12.0001 1.99994C11.1717 1.99994 10.5001 2.67151 10.5001 3.49994V10.4999H3.50006C2.67163 10.4999 2.00006 11.1715 2.00006 11.9999C2.00006 12.8284 2.67163 13.4999 3.50006 13.4999H10.5001V20.4999C10.5001 21.3284 11.1717 21.9999 12.0001 21.9999C12.8285 21.9999 13.5001 21.3284 13.5001 20.4999V13.4999H20.5001C21.3285 13.4999 22.0001 12.8284 22.0001 11.9999C22.0001 11.1715 21.3285 10.4999 20.5001 10.4999H13.5001V3.49994C13.5001 2.67151 12.8285 1.99994 12.0001 1.99994Z" />
    </svg>
);


export default function AuthPage({ auth }) { // <--- 接收從 App.jsx 傳來的 auth 物件
    const [isLogin, setIsLogin] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    
    // const auth = getAuth(); // <--- 移除此行，改用 props

    const handleAuthAction = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');

        if (!isLogin && password.length < 6) {
            setError('密碼長度至少需要 6 個字元。');
            setIsLoading(false);
            return;
        }

        if (!isLogin && password !== confirmPassword) {
            setError('兩次輸入的密碼不一致。');
            setIsLoading(false);
            return;
        }

        try {
            if (isLogin) {
                await signInWithEmailAndPassword(auth, email, password);
            } else {
                await createUserWithEmailAndPassword(auth, email, password);
            }
            // 登入/註冊成功後，App.jsx 中的 onAuthStateChanged 會自動處理頁面跳轉
        } catch (err) {
            // 將 Firebase 的錯誤訊息轉換為更友善的中文提示
            switch (err.code) {
                case 'auth/email-already-in-use':
                    setError('此電子郵件已經被註冊。');
                    break;
                case 'auth/user-not-found':
                case 'auth/wrong-password':
                case 'auth/invalid-credential':
                    setError('電子郵件或密碼錯誤。');
                    break;
                case 'auth/invalid-email':
                    setError('電子郵件格式不正確。');
                    break;
                default:
                    setError('發生未知錯誤，請稍後再試。');
                    console.error("Firebase Auth Error:", err);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const handleGoogleSignIn = async () => {
        const provider = new GoogleAuthProvider();
        try {
            await signInWithPopup(auth, provider);
        } catch (err) {
            setError('使用 Google 登入失敗，請稍後再試。');
            console.error("Google Sign-In Error:", err);
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-50">
            <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-xl shadow-lg m-4">
                <div className="text-center">
                    <AppLogo />
                    <h1 className="mt-4 text-3xl font-bold text-gray-900">Promo App</h1>
                    <p className="mt-2 text-sm text-gray-600">
                        {isLogin ? '登入以繼續' : '建立您的新帳號'}
                    </p>
                </div>

                {/* 頁籤切換 */}
                <div className="flex border-b-2 border-gray-200">
                    <button
                        onClick={() => { setIsLogin(true); setError(''); }}
                        className={`flex-1 py-3 font-semibold text-center transition-colors duration-300 ${isLogin ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        登入
                    </button>
                    <button
                        onClick={() => { setIsLogin(false); setError(''); }}
                        className={`flex-1 py-3 font-semibold text-center transition-colors duration-300 ${!isLogin ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        註冊
                    </button>
                </div>
                
                {/* 錯誤訊息顯示區 */}
                {error && (
                    <div className="p-3 text-sm font-medium text-red-800 bg-red-100 border border-red-200 rounded-lg" role="alert">
                        {error}
                    </div>
                )}
                
                <form onSubmit={handleAuthAction} className="space-y-4">
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">電子郵件</label>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                            placeholder="you@example.com"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-700">密碼</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                            placeholder="••••••••"
                        />
                    </div>
                    
                    {!isLogin && (
                        <div>
                            <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">確認密碼</label>
                            <input
                                id="confirmPassword"
                                type="password"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                className="w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                                required
                                placeholder="••••••••"
                            />
                        </div>
                    )}
                    
                    {isLogin && (
                        <div className="text-sm text-right">
                            <a href="#" className="font-medium text-indigo-600 hover:text-indigo-500">
                                忘記密碼？
                            </a>
                        </div>
                    )}

                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 disabled:cursor-not-allowed"
                    >
                        {isLoading ? (
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        ) : null}
                        {isLoading ? '處理中...' : (isLogin ? '登入' : '建立帳號')}
                    </button>
                </form>

                <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-300"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                        <span className="px-2 text-gray-500 bg-white">或透過以下方式繼續</span>
                    </div>
                </div>

                <div>
                    <button onClick={handleGoogleSignIn} className="w-full flex items-center justify-center py-2.5 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                        <svg className="w-5 h-5 mr-2" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512">
                            <path fill="currentColor" d="M488 261.8C488 403.3 381.5 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 126 25.4 172.1 65.8l-68.5 68.5C322.4 112.8 288.2 96 248 96c-88.6 0-160.1 71.5-160.1 160s71.5 160 160.1 160c94.9 0 138.8-66.2 143.9-105.2H248v-85.3h236.1c2.3 12.7 3.9 26.1 3.9 40.2z"></path>
                        </svg>
                        使用 Google 帳號登入
                    </button>
                </div>
            </div>
        </div>
    );
}

